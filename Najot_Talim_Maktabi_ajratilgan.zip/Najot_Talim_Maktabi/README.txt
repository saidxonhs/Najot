Najot Ta'lim Maktabi — ajratilgan fayllar

Fayllar:
- index.html — sahifaning HTML tuzilishi
- style.css — dizayn va CSS qoidalari
- script.js — JavaScript funksiyalari

Ishlatish:
1. Uchala faylni bitta papkada saqlang.
2. index.html faylini brauzerda oching.
3. Sayt ma'lumotlari brauzerning localStorage xotirasida saqlanadi.

Eslatma:
Sayt dastlab bitta HTML faylida edi. CSS va JavaScript ajratilib, HTML ularga havola qilindi.
